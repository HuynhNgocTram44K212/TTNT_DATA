﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;

namespace QuảnLýSinhViên
{
    public partial class _4_Report : Form
    {
        public _4_Report()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");
        private void _4_Report_Load(object sender, EventArgs e)
        {
            var cmd = new SqlCommand("Select * From DMLOP", conn);
            cmd.CommandType = CommandType.Text;
            var dap = new SqlDataAdapter(cmd);
            // var dap = new SqlDataAdapter("SELECT*FROM PhongBan", conn); thay bằng câu lệnh trên
            var table = new DataTable();
            dap.Fill(table);
            cbLop.DisplayMember = "TenLop";
            cbLop.ValueMember = "IDLop";
            cbLop.DataSource = table;
            txtIDLop.DataBindings.Clear();
            txtIDLop.DataBindings.Add("Text", cbLop.DataSource, "IDLop");
            this.reportViewer1.RefreshReport();
        }

        private void btReport_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = Properties.Settings.Default.QLHocVienConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "TKHV_Report";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            cmd.Parameters.Add(new SqlParameter("@TenLop", cbLop.Text));
            DataSet ds = new DataSet();
            SqlDataAdapter dap = new SqlDataAdapter(cmd);
            dap.Fill(ds);
            reportViewer1.ProcessingMode = ProcessingMode.Local;
            reportViewer1.LocalReport.ReportPath = "rpHV.rdlc";
            ReportDataSource rds = new ReportDataSource();
            rds.Name = "dsReport";
            rds.Value = ds.Tables[0];
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(rds);
            reportViewer1.RefreshReport();
        }
    }
}
