﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuảnLýSinhViên
{
    public partial class _4_Delete : Form
    {
        public _4_Delete()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");
        private void _4_Delete_Load(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("DMLOP_SELECTALL", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                var dap = new SqlDataAdapter(cmd);
                // var dap = new SqlDataAdapter("SELECT*FROM PhongBan", conn); thay bằng câu lệnh trên
                var table = new DataTable();
                dap.Fill(table);
                cbTenlop3.DisplayMember = "TenLop";
                cbTenlop3.ValueMember = "IDLop";
                cbTenlop3.DataSource = table;
                textIDlop3.DataBindings.Clear();
                textIDlop3.DataBindings.Add("Text", cbTenlop3.DataSource, "IDLop");
                textTenlop3.DataBindings.Clear();
                textTenlop3.DataBindings.Add("Text", cbTenlop3.DataSource, "TenLop");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbTenlop3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("HOCVIEN_SELECTID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbTenlop3.SelectedValue);
                var dap = new SqlDataAdapter(cmd);
                var table = new DataTable();
                dap.Fill(table);
                dsHocvien3.DataSource = table;
                textIDhv3.DataBindings.Clear();
                textIDhv3.DataBindings.Add("Text", dsHocvien3.DataSource, "IDHocVien");
                textTenhv3.DataBindings.Clear();
                textTenhv3.DataBindings.Add("Text", dsHocvien3.DataSource, "TenHocVien");
                texthp3.DataBindings.Clear();
                texthp3.DataBindings.Add("Text", dsHocvien3.DataSource, "HocPhi");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            DialogResult lenh = MessageBox.Show(" Bạn có chắc chắn muốn xóa nhân viên" + textTenhv3.Text + "???",
                "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (lenh == DialogResult.Yes)
            {
                try
                {
                    conn.Open();
                    var cmd = new SqlCommand("HOCVIEN_DELETE", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@IDHocVien", SqlDbType.Int).Value = Convert.ToInt32(textIDhv3.Text);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    cbTenlop3_SelectedIndexChanged(sender, e);
                    MessageBox.Show("Xóa dữ liệu thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Xóa dữ liệu thất bại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnclose2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
