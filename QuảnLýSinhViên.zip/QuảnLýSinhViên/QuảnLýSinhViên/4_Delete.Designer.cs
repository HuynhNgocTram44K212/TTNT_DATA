﻿namespace QuảnLýSinhViên
{
    partial class _4_Delete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textTenlop3 = new System.Windows.Forms.TextBox();
            this.textIDlop3 = new System.Windows.Forms.TextBox();
            this.btndelete = new System.Windows.Forms.Button();
            this.texthp3 = new System.Windows.Forms.TextBox();
            this.cbTenlop3 = new System.Windows.Forms.ComboBox();
            this.btnclose2 = new System.Windows.Forms.Button();
            this.textTenhv3 = new System.Windows.Forms.TextBox();
            this.textIDhv3 = new System.Windows.Forms.TextBox();
            this.dsHocvien3 = new System.Windows.Forms.DataGridView();
            this.IDHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien3)).BeginInit();
            this.SuspendLayout();
            // 
            // textTenlop3
            // 
            this.textTenlop3.Location = new System.Drawing.Point(416, 40);
            this.textTenlop3.Name = "textTenlop3";
            this.textTenlop3.Size = new System.Drawing.Size(98, 20);
            this.textTenlop3.TabIndex = 43;
            // 
            // textIDlop3
            // 
            this.textIDlop3.Enabled = false;
            this.textIDlop3.Location = new System.Drawing.Point(248, 40);
            this.textIDlop3.Name = "textIDlop3";
            this.textIDlop3.Size = new System.Drawing.Size(100, 20);
            this.textIDlop3.TabIndex = 42;
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btndelete.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btndelete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btndelete.Location = new System.Drawing.Point(314, 300);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(85, 23);
            this.btndelete.TabIndex = 41;
            this.btndelete.Text = "Xóa";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // texthp3
            // 
            this.texthp3.Location = new System.Drawing.Point(109, 307);
            this.texthp3.Name = "texthp3";
            this.texthp3.Size = new System.Drawing.Size(121, 20);
            this.texthp3.TabIndex = 39;
            // 
            // cbTenlop3
            // 
            this.cbTenlop3.FormattingEnabled = true;
            this.cbTenlop3.Location = new System.Drawing.Point(67, 40);
            this.cbTenlop3.Name = "cbTenlop3";
            this.cbTenlop3.Size = new System.Drawing.Size(94, 21);
            this.cbTenlop3.TabIndex = 38;
            this.cbTenlop3.SelectedIndexChanged += new System.EventHandler(this.cbTenlop3_SelectedIndexChanged);
            // 
            // btnclose2
            // 
            this.btnclose2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnclose2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnclose2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnclose2.Location = new System.Drawing.Point(431, 300);
            this.btnclose2.Name = "btnclose2";
            this.btnclose2.Size = new System.Drawing.Size(85, 23);
            this.btnclose2.TabIndex = 37;
            this.btnclose2.Text = "Đóng";
            this.btnclose2.UseVisualStyleBackColor = false;
            this.btnclose2.Click += new System.EventHandler(this.btnclose2_Click);
            // 
            // textTenhv3
            // 
            this.textTenhv3.Location = new System.Drawing.Point(109, 280);
            this.textTenhv3.Name = "textTenhv3";
            this.textTenhv3.Size = new System.Drawing.Size(121, 20);
            this.textTenhv3.TabIndex = 36;
            // 
            // textIDhv3
            // 
            this.textIDhv3.Enabled = false;
            this.textIDhv3.Location = new System.Drawing.Point(109, 253);
            this.textIDhv3.Name = "textIDhv3";
            this.textIDhv3.Size = new System.Drawing.Size(121, 20);
            this.textIDhv3.TabIndex = 35;
            // 
            // dsHocvien3
            // 
            this.dsHocvien3.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dsHocvien3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dsHocvien3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDHocVien,
            this.TenHocVien,
            this.HocPhi,
            this.IDLop});
            this.dsHocvien3.Location = new System.Drawing.Point(28, 71);
            this.dsHocvien3.Name = "dsHocvien3";
            this.dsHocvien3.Size = new System.Drawing.Size(485, 176);
            this.dsHocvien3.TabIndex = 34;
            // 
            // IDHocVien
            // 
            this.IDHocVien.DataPropertyName = "IDHocVien";
            this.IDHocVien.HeaderText = "ID Học Viên";
            this.IDHocVien.Name = "IDHocVien";
            // 
            // TenHocVien
            // 
            this.TenHocVien.DataPropertyName = "TenHocVien";
            this.TenHocVien.HeaderText = "Tên Học Viên";
            this.TenHocVien.Name = "TenHocVien";
            this.TenHocVien.Width = 150;
            // 
            // HocPhi
            // 
            this.HocPhi.DataPropertyName = "HocPhi";
            this.HocPhi.HeaderText = "HọcPhí";
            this.HocPhi.Name = "HocPhi";
            this.HocPhi.Width = 150;
            // 
            // IDLop
            // 
            this.IDLop.DataPropertyName = "IDLop";
            this.IDLop.HeaderText = "ID lớp";
            this.IDLop.Name = "IDLop";
            this.IDLop.Visible = false;
            // 
            // _4_Delete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::QuảnLýSinhViên.Properties.Resources.XÓA1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(557, 340);
            this.Controls.Add(this.textTenlop3);
            this.Controls.Add(this.textIDlop3);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.texthp3);
            this.Controls.Add(this.cbTenlop3);
            this.Controls.Add(this.btnclose2);
            this.Controls.Add(this.textTenhv3);
            this.Controls.Add(this.textIDhv3);
            this.Controls.Add(this.dsHocvien3);
            this.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.Name = "_4_Delete";
            this.Text = "_4_Delete";
            this.Load += new System.EventHandler(this._4_Delete_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textTenlop3;
        private System.Windows.Forms.TextBox textIDlop3;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.TextBox texthp3;
        private System.Windows.Forms.ComboBox cbTenlop3;
        private System.Windows.Forms.Button btnclose2;
        private System.Windows.Forms.TextBox textTenhv3;
        private System.Windows.Forms.TextBox textIDhv3;
        private System.Windows.Forms.DataGridView dsHocvien3;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn HocPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDLop;
    }
}