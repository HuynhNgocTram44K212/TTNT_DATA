﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace QuảnLýSinhViên
{
    public partial class _4_Search : Form
    {
        public _4_Search()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");

        private void _4_Search_Load(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("DMLOP_SELECTALL", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                var dap = new SqlDataAdapter(cmd);
                // var dap = new SqlDataAdapter("SELECT*FROM PhongBan", conn); thay bằng câu lệnh trên
                var table = new DataTable();
                dap.Fill(table);
                cbTenlop4.DisplayMember = "TenLop";
                cbTenlop4.ValueMember = "IDLop";
                cbTenlop4.DataSource = table;
                textIDlop4.DataBindings.Clear();
                textIDlop4.DataBindings.Add("Text", cbTenlop4.DataSource, "IDLop");
                
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbTenlop4_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("HOCVIEN_SELECTID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbTenlop4.SelectedValue);
                var dap = new SqlDataAdapter(cmd);
                var table = new DataTable();
                dap.Fill(table);
                dsHocvien4.DataSource = table;
             
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void timdata()
        {
          try
           {
                if (!textfind.Text.Equals(""))
                {
                    
                  
                    var cmd = new SqlCommand();
                    cmd = conn.CreateCommand();
                    cmd.CommandText = "Select IDHocVien, TenHocVien, HocPhi from DMLOP inner join HOCVIEN on HOCVIEN.IDLop = DMLOP.IDLop where TenHocVien like N'%" + textfind.Text + "%' and TenLop=N'" + cbTenlop4.Text + "'";
                    var dap = new SqlDataAdapter(cmd);
                    var table = new DataTable();
                    dap.SelectCommand = cmd;
                    table.Clear();
                    dap.Fill(table);
                    dsHocvien4.DataSource = table;
                }
            
                else
                {
                    MessageBox.Show("Bạn chưa ghi Tên Học Viên", "Thông báo",MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
           catch
          { 
                MessageBox.Show("Tìm kiếm bị lỗi!", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Error);
          }
        }
        
        

        private void btnsearch_Click_1(object sender, EventArgs e)
        {
            timdata();

        }

        private void btnclose4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
