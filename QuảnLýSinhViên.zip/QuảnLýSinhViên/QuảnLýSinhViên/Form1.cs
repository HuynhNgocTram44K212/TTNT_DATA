﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuảnLýSinhViên
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        private void dangnhap()
        {
            if (Tendn.Text.Length == 0 && Mk.Text.Length == 0)
                MessageBox.Show("Bạn chưa đăng nhập!", "Thông báo", MessageBoxButtons.OK,MessageBoxIcon.Error);
            else
                if (this.Tendn.Text.Length == 0)
                    MessageBox.Show("Bạn chưa nhập tên đăng nhập!","Thông báo", MessageBoxButtons.OK,MessageBoxIcon.Error);
                else
                    if (this.Mk.Text.Length == 0)
                        MessageBox.Show("Bạn chưa nhập mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                        if (this.Tendn.Text == "admin" && this.Mk.Text == "admin")
                            MessageBox.Show("Đăng nhập thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("Tài khoản hoặc Mật khẩu của bạn không đúng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void btnlogin_Click(object sender, EventArgs e)
        {
            _4_Main fr = new _4_Main();
            if (this.Tendn.Text == "admin" && this.Mk.Text == "admin")
            {
                fr.Show();
            }
            dangnhap();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
