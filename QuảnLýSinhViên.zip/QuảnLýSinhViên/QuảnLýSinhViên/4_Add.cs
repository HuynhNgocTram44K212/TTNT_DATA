﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuảnLýSinhViên
{
    public partial class _4_Add : Form
    {
        public _4_Add()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");

        private void _4_Add_Load(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("DMLOP_SELECTALL", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                var dap = new SqlDataAdapter(cmd);
                // var dap = new SqlDataAdapter("SELECT*FROM PhongBan", conn); thay bằng câu lệnh trên
                var table = new DataTable();
                dap.Fill(table);
                cbTenlop.DisplayMember = "TenLop";
                cbTenlop.ValueMember = "IDLop";
                cbTenlop.DataSource = table;
                textIDlop.DataBindings.Clear();
                textIDlop.DataBindings.Add("Text", cbTenlop.DataSource, "IDLop");
                textTenlop.DataBindings.Clear();
                textTenlop.DataBindings.Add("Text", cbTenlop.DataSource, "TenLop");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbTenlop_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("HOCVIEN_SELECTID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbTenlop.SelectedValue);
                var dap = new SqlDataAdapter(cmd);
                var table = new DataTable();
                dap.Fill(table);
                dsHocvien.DataSource = table;
                textIDhv.DataBindings.Clear();
                textIDhv.DataBindings.Add("Text", dsHocvien.DataSource, "IDHocVien");
                textTenhv.DataBindings.Clear();
                textTenhv.DataBindings.Add("Text", dsHocvien.DataSource, "TenHocVien");
                texthp.DataBindings.Clear();
                texthp.DataBindings.Add("Text", dsHocvien.DataSource, "HocPhi");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        Boolean addNV = false;
        private void btnadd_Click(object sender, EventArgs e)
        {
            textIDhv.Text = "";
            textTenhv.Text = "";
            texthp.Text = "";
            textTenhv.Focus();
            addNV = true;
        }
       
        private void btnsave_Click(object sender, EventArgs e)
        {
            if (this.textTenlop.TextLength ==0 || this.texthp.TextLength== 0)
            {
                MessageBox.Show("Bạn vui lòng điền đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    conn.Open();
                    var cmd = new SqlCommand("HOCVIEN_ADD", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@TenHocVien", SqlDbType.NVarChar).Value = textTenhv.Text;
                    cmd.Parameters.Add("@HocPhi", SqlDbType.Int).Value = texthp.Text;
                    cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbTenlop.SelectedValue);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    cbTenlop_SelectedIndexChanged(sender, e);
                    MessageBox.Show("Thêm NV thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // tat che do them vao khi da them vao xong
                    addNV = false;

                }
                catch
                {

                    MessageBox.Show("Thêm NV thất bại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
       //     try
        //    {   
          //          conn.Open();
           //         var cmd = new SqlCommand("HOCVIEN_ADD", conn);
            //        cmd.CommandType = CommandType.StoredProcedure;
             //       cmd.Parameters.Add("@TenHocVien", SqlDbType.NVarChar).Value = textTenhv.Text;
             //       cmd.Parameters.Add("@HocPhi", SqlDbType.Int).Value = texthp.Text;
              //      cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbTenlop.SelectedValue);
              //      cmd.ExecuteNonQuery();
              //      conn.Close();
             //       cbTenlop_SelectedIndexChanged(sender, e);
            //        MessageBox.Show("Thêm NV thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        // tat che do them vao khi da them vao xong
            //        addNV = false;
                
          //  }
          //  catch
          //  {

           //     MessageBox.Show("Thêm NV thất bại! Vui lòng nhập đầy đủ Tên học viên và Học phí!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
          //  }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

    }
}
           
        
    


