﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuảnLýSinhViên
{
    public partial class _4_Update : Form
    {
        public _4_Update()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");

        private void _4_Update_Load(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("DMLOP_SELECTALL", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                var dap = new SqlDataAdapter(cmd);
                // var dap = new SqlDataAdapter("SELECT*FROM PhongBan", conn); thay bằng câu lệnh trên
                var table = new DataTable();
                dap.Fill(table);
                cbTenlop2.DisplayMember = "TenLop";
                cbTenlop2.ValueMember = "IDLop";
                cbTenlop2.DataSource = table;
                textIDlop2.DataBindings.Clear();
                textIDlop2.DataBindings.Add("Text", cbTenlop2.DataSource, "IDLop");
                textTenlop2.DataBindings.Clear();
                textTenlop2.DataBindings.Add("Text", cbTenlop2.DataSource, "TenLop");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbTenlop2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("HOCVIEN_SELECTID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbTenlop2.SelectedValue);
                var dap = new SqlDataAdapter(cmd);
                var table = new DataTable();
                dap.Fill(table);
                dsHocvien2.DataSource = table;
                textIDhv2.DataBindings.Clear();
                textIDhv2.DataBindings.Add("Text", dsHocvien2.DataSource, "IDHocVien");
                textTenhv2.DataBindings.Clear();
                textTenhv2.DataBindings.Add("Text", dsHocvien2.DataSource, "TenHocVien");
                texthp2.DataBindings.Clear();
                texthp2.DataBindings.Add("Text", dsHocvien2.DataSource, "HocPhi");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                var cmd = new SqlCommand("HOCVIEN_UPDATE", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@TenHocVien", SqlDbType.NVarChar).Value = textTenhv2.Text;
                cmd.Parameters.Add("@HocPhi", SqlDbType.Int).Value = texthp2.Text;
                cmd.Parameters.Add("@IDHocVien", SqlDbType.Int).Value = Convert.ToInt32(textIDhv2.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                cbTenlop2_SelectedIndexChanged(sender, e);
                MessageBox.Show("Cập nhật thông tin nhân Viên thành công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Cập nhật thông tin nhân viên thất bại!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnclose2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
