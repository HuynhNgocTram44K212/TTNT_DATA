﻿namespace QuảnLýSinhViên
{
    partial class _4_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dsHocvien = new System.Windows.Forms.DataGridView();
            this.IDHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textIDhv = new System.Windows.Forms.TextBox();
            this.textTenhv = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.cbTenlop = new System.Windows.Forms.ComboBox();
            this.texthp = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.textIDlop = new System.Windows.Forms.TextBox();
            this.textTenlop = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien)).BeginInit();
            this.SuspendLayout();
            // 
            // dsHocvien
            // 
            this.dsHocvien.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dsHocvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dsHocvien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDHocVien,
            this.TenHocVien,
            this.HocPhi,
            this.IDLop});
            this.dsHocvien.Location = new System.Drawing.Point(27, 74);
            this.dsHocvien.Name = "dsHocvien";
            this.dsHocvien.Size = new System.Drawing.Size(481, 156);
            this.dsHocvien.TabIndex = 3;
            // 
            // IDHocVien
            // 
            this.IDHocVien.DataPropertyName = "IDHocVien";
            this.IDHocVien.HeaderText = "ID Học Viên";
            this.IDHocVien.Name = "IDHocVien";
            // 
            // TenHocVien
            // 
            this.TenHocVien.DataPropertyName = "TenHocVien";
            this.TenHocVien.HeaderText = "Tên Học Viên";
            this.TenHocVien.Name = "TenHocVien";
            this.TenHocVien.Width = 150;
            // 
            // HocPhi
            // 
            this.HocPhi.DataPropertyName = "HocPhi";
            this.HocPhi.HeaderText = "HọcPhí";
            this.HocPhi.Name = "HocPhi";
            this.HocPhi.Width = 150;
            // 
            // IDLop
            // 
            this.IDLop.DataPropertyName = "IDLop";
            this.IDLop.HeaderText = "ID lớp";
            this.IDLop.Name = "IDLop";
            this.IDLop.Visible = false;
            // 
            // textIDhv
            // 
            this.textIDhv.Enabled = false;
            this.textIDhv.Location = new System.Drawing.Point(119, 236);
            this.textIDhv.Name = "textIDhv";
            this.textIDhv.Size = new System.Drawing.Size(121, 20);
            this.textIDhv.TabIndex = 4;
            // 
            // textTenhv
            // 
            this.textTenhv.Location = new System.Drawing.Point(119, 268);
            this.textTenhv.Name = "textTenhv";
            this.textTenhv.Size = new System.Drawing.Size(121, 20);
            this.textTenhv.TabIndex = 5;
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnadd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnadd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnadd.Location = new System.Drawing.Point(270, 305);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(75, 23);
            this.btnadd.TabIndex = 7;
            this.btnadd.Text = "Thêm";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnclose.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnclose.Location = new System.Drawing.Point(449, 305);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(75, 23);
            this.btnclose.TabIndex = 9;
            this.btnclose.Text = "Đóng";
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // cbTenlop
            // 
            this.cbTenlop.FormattingEnabled = true;
            this.cbTenlop.Location = new System.Drawing.Point(88, 47);
            this.cbTenlop.Name = "cbTenlop";
            this.cbTenlop.Size = new System.Drawing.Size(83, 21);
            this.cbTenlop.TabIndex = 0;
            this.cbTenlop.SelectedIndexChanged += new System.EventHandler(this.cbTenlop_SelectedIndexChanged);
            // 
            // texthp
            // 
            this.texthp.Location = new System.Drawing.Point(119, 298);
            this.texthp.Name = "texthp";
            this.texthp.Size = new System.Drawing.Size(121, 20);
            this.texthp.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.label4.Location = new System.Drawing.Point(25, 232);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 15);
            this.label4.TabIndex = 13;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnsave.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnsave.Location = new System.Drawing.Point(359, 305);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 8;
            this.btnsave.Text = "Lưu";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // textIDlop
            // 
            this.textIDlop.Enabled = false;
            this.textIDlop.Location = new System.Drawing.Point(239, 48);
            this.textIDlop.Name = "textIDlop";
            this.textIDlop.Size = new System.Drawing.Size(85, 20);
            this.textIDlop.TabIndex = 1;
            // 
            // textTenlop
            // 
            this.textTenlop.Location = new System.Drawing.Point(399, 47);
            this.textTenlop.Name = "textTenlop";
            this.textTenlop.Size = new System.Drawing.Size(100, 20);
            this.textTenlop.TabIndex = 2;
            // 
            // _4_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::QuảnLýSinhViên.Properties.Resources.qqqq1111;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(557, 340);
            this.Controls.Add(this.textTenlop);
            this.Controls.Add(this.textIDlop);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.texthp);
            this.Controls.Add(this.cbTenlop);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.textTenhv);
            this.Controls.Add(this.textIDhv);
            this.Controls.Add(this.dsHocvien);
            this.Name = "_4_Add";
            this.Text = "_4_Add";
            this.Load += new System.EventHandler(this._4_Add_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dsHocvien;
        private System.Windows.Forms.TextBox textIDhv;
        private System.Windows.Forms.TextBox textTenhv;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.ComboBox cbTenlop;
        private System.Windows.Forms.TextBox texthp;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox textIDlop;
        private System.Windows.Forms.TextBox textTenlop;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn HocPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDLop;
    }
}