﻿namespace QuảnLýSinhViên
{
    partial class _4_Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textTenlop2 = new System.Windows.Forms.TextBox();
            this.textIDlop2 = new System.Windows.Forms.TextBox();
            this.btnupdate = new System.Windows.Forms.Button();
            this.cbTenlop2 = new System.Windows.Forms.ComboBox();
            this.btnclose2 = new System.Windows.Forms.Button();
            this.dsHocvien2 = new System.Windows.Forms.DataGridView();
            this.IDHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textIDhv2 = new System.Windows.Forms.TextBox();
            this.textTenhv2 = new System.Windows.Forms.TextBox();
            this.texthp2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien2)).BeginInit();
            this.SuspendLayout();
            // 
            // textTenlop2
            // 
            this.textTenlop2.Location = new System.Drawing.Point(428, 40);
            this.textTenlop2.Name = "textTenlop2";
            this.textTenlop2.Size = new System.Drawing.Size(83, 20);
            this.textTenlop2.TabIndex = 2;
            // 
            // textIDlop2
            // 
            this.textIDlop2.Enabled = false;
            this.textIDlop2.Location = new System.Drawing.Point(254, 38);
            this.textIDlop2.Name = "textIDlop2";
            this.textIDlop2.Size = new System.Drawing.Size(83, 20);
            this.textIDlop2.TabIndex = 1;
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnupdate.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnupdate.Location = new System.Drawing.Point(313, 267);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(85, 23);
            this.btnupdate.TabIndex = 7;
            this.btnupdate.Text = "Cập Nhật";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // cbTenlop2
            // 
            this.cbTenlop2.FormattingEnabled = true;
            this.cbTenlop2.Location = new System.Drawing.Point(60, 44);
            this.cbTenlop2.Name = "cbTenlop2";
            this.cbTenlop2.Size = new System.Drawing.Size(101, 21);
            this.cbTenlop2.TabIndex = 0;
            this.cbTenlop2.SelectedIndexChanged += new System.EventHandler(this.cbTenlop2_SelectedIndexChanged);
            // 
            // btnclose2
            // 
            this.btnclose2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnclose2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnclose2.Location = new System.Drawing.Point(313, 297);
            this.btnclose2.Name = "btnclose2";
            this.btnclose2.Size = new System.Drawing.Size(85, 23);
            this.btnclose2.TabIndex = 8;
            this.btnclose2.Text = "Đóng";
            this.btnclose2.UseVisualStyleBackColor = false;
            this.btnclose2.Click += new System.EventHandler(this.btnclose2_Click);
            // 
            // dsHocvien2
            // 
            this.dsHocvien2.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dsHocvien2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dsHocvien2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDHocVien,
            this.TenHocVien,
            this.HocPhi,
            this.IDLop});
            this.dsHocvien2.Location = new System.Drawing.Point(22, 70);
            this.dsHocvien2.Name = "dsHocvien2";
            this.dsHocvien2.Size = new System.Drawing.Size(489, 180);
            this.dsHocvien2.TabIndex = 3;
            // 
            // IDHocVien
            // 
            this.IDHocVien.DataPropertyName = "IDHocVien";
            this.IDHocVien.HeaderText = "ID Học Viên";
            this.IDHocVien.Name = "IDHocVien";
            // 
            // TenHocVien
            // 
            this.TenHocVien.DataPropertyName = "TenHocVien";
            this.TenHocVien.HeaderText = "Tên Học Viên";
            this.TenHocVien.Name = "TenHocVien";
            this.TenHocVien.Width = 150;
            // 
            // HocPhi
            // 
            this.HocPhi.DataPropertyName = "HocPhi";
            this.HocPhi.HeaderText = "HọcPhí";
            this.HocPhi.Name = "HocPhi";
            this.HocPhi.Width = 150;
            // 
            // IDLop
            // 
            this.IDLop.DataPropertyName = "IDLop";
            this.IDLop.HeaderText = "ID lớp";
            this.IDLop.Name = "IDLop";
            this.IDLop.Visible = false;
            // 
            // textIDhv2
            // 
            this.textIDhv2.Enabled = false;
            this.textIDhv2.Location = new System.Drawing.Point(117, 256);
            this.textIDhv2.Name = "textIDhv2";
            this.textIDhv2.Size = new System.Drawing.Size(121, 20);
            this.textIDhv2.TabIndex = 4;
            // 
            // textTenhv2
            // 
            this.textTenhv2.Location = new System.Drawing.Point(117, 284);
            this.textTenhv2.Name = "textTenhv2";
            this.textTenhv2.Size = new System.Drawing.Size(121, 20);
            this.textTenhv2.TabIndex = 5;
            // 
            // texthp2
            // 
            this.texthp2.Location = new System.Drawing.Point(117, 310);
            this.texthp2.Name = "texthp2";
            this.texthp2.Size = new System.Drawing.Size(121, 20);
            this.texthp2.TabIndex = 6;
            // 
            // _4_Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::QuảnLýSinhViên.Properties.Resources.UPDATE;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(557, 340);
            this.Controls.Add(this.textTenlop2);
            this.Controls.Add(this.textIDlop2);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.texthp2);
            this.Controls.Add(this.cbTenlop2);
            this.Controls.Add(this.btnclose2);
            this.Controls.Add(this.textTenhv2);
            this.Controls.Add(this.textIDhv2);
            this.Controls.Add(this.dsHocvien2);
            this.DoubleBuffered = true;
            this.Name = "_4_Update";
            this.Text = "_4_Update";
            this.Load += new System.EventHandler(this._4_Update_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textTenlop2;
        private System.Windows.Forms.TextBox textIDlop2;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.ComboBox cbTenlop2;
        private System.Windows.Forms.Button btnclose2;
        private System.Windows.Forms.DataGridView dsHocvien2;
        private System.Windows.Forms.TextBox textIDhv2;
        private System.Windows.Forms.TextBox textTenhv2;
        private System.Windows.Forms.TextBox texthp2;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn HocPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDLop;


    }
}