﻿namespace QuảnLýSinhViên
{
    partial class _4_Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textIDlop4 = new System.Windows.Forms.TextBox();
            this.cbTenlop4 = new System.Windows.Forms.ComboBox();
            this.dsHocvien4 = new System.Windows.Forms.DataGridView();
            this.IDHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textfind = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnclose4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien4)).BeginInit();
            this.SuspendLayout();
            // 
            // textIDlop4
            // 
            this.textIDlop4.Enabled = false;
            this.textIDlop4.Location = new System.Drawing.Point(78, 41);
            this.textIDlop4.Name = "textIDlop4";
            this.textIDlop4.Size = new System.Drawing.Size(100, 20);
            this.textIDlop4.TabIndex = 0;
            // 
            // cbTenlop4
            // 
            this.cbTenlop4.FormattingEnabled = true;
            this.cbTenlop4.Location = new System.Drawing.Point(249, 39);
            this.cbTenlop4.Name = "cbTenlop4";
            this.cbTenlop4.Size = new System.Drawing.Size(104, 21);
            this.cbTenlop4.TabIndex = 1;
            this.cbTenlop4.SelectedIndexChanged += new System.EventHandler(this.cbTenlop4_SelectedIndexChanged);
            // 
            // dsHocvien4
            // 
            this.dsHocvien4.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dsHocvien4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dsHocvien4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDHocVien,
            this.TenHocVien,
            this.HocPhi,
            this.IDLop});
            this.dsHocvien4.Location = new System.Drawing.Point(26, 67);
            this.dsHocvien4.Name = "dsHocvien4";
            this.dsHocvien4.Size = new System.Drawing.Size(508, 238);
            this.dsHocvien4.TabIndex = 3;
            // 
            // IDHocVien
            // 
            this.IDHocVien.DataPropertyName = "IDHocVien";
            this.IDHocVien.HeaderText = "ID Học Viên";
            this.IDHocVien.Name = "IDHocVien";
            // 
            // TenHocVien
            // 
            this.TenHocVien.DataPropertyName = "TenHocVien";
            this.TenHocVien.HeaderText = "Tên Học Viên";
            this.TenHocVien.Name = "TenHocVien";
            this.TenHocVien.Width = 170;
            // 
            // HocPhi
            // 
            this.HocPhi.DataPropertyName = "HocPhi";
            this.HocPhi.HeaderText = "HọcPhí";
            this.HocPhi.Name = "HocPhi";
            this.HocPhi.Width = 200;
            // 
            // IDLop
            // 
            this.IDLop.DataPropertyName = "IDLop";
            this.IDLop.HeaderText = "ID lớp";
            this.IDLop.Name = "IDLop";
            this.IDLop.Visible = false;
            // 
            // textfind
            // 
            this.textfind.Location = new System.Drawing.Point(430, 40);
            this.textfind.Name = "textfind";
            this.textfind.Size = new System.Drawing.Size(104, 20);
            this.textfind.TabIndex = 2;
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnsearch.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnsearch.Location = new System.Drawing.Point(354, 311);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(85, 23);
            this.btnsearch.TabIndex = 4;
            this.btnsearch.Text = "Tìm kiếm";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click_1);
            // 
            // btnclose4
            // 
            this.btnclose4.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnclose4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnclose4.Location = new System.Drawing.Point(445, 311);
            this.btnclose4.Name = "btnclose4";
            this.btnclose4.Size = new System.Drawing.Size(75, 23);
            this.btnclose4.TabIndex = 5;
            this.btnclose4.Text = "Đóng";
            this.btnclose4.UseVisualStyleBackColor = false;
            this.btnclose4.Click += new System.EventHandler(this.btnclose4_Click);
            // 
            // _4_Search
            // 
            this.AcceptButton = this.btnsearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::QuảnLýSinhViên.Properties.Resources.TÌM;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(557, 340);
            this.Controls.Add(this.textfind);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.btnclose4);
            this.Controls.Add(this.textIDlop4);
            this.Controls.Add(this.cbTenlop4);
            this.Controls.Add(this.dsHocvien4);
            this.DoubleBuffered = true;
            this.Name = "_4_Search";
            this.Text = "_4_Search";
            this.Load += new System.EventHandler(this._4_Search_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dsHocvien4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textIDlop4;
        private System.Windows.Forms.ComboBox cbTenlop4;
        private System.Windows.Forms.DataGridView dsHocvien4;
        private System.Windows.Forms.TextBox textfind;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnclose4;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn HocPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDLop;
    }
}