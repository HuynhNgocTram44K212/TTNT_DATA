﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QuảnLýSinhViên
{
    public partial class _4_Main : Form
    {
        public _4_Main()
        {
            InitializeComponent();
        }
        


        private void aDDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool IsOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "_4_Add")
                {
                    IsOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (IsOpen == false)
            {
                _4_Add f2 = new _4_Add();
                f2.MdiParent = this;
                f2.Show();
            }
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool IsOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "_4_Update")
                {
                    IsOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (IsOpen == false)
            {
                _4_Update f3 = new _4_Update();
                f3.MdiParent = this;
                f3.Show();
            }
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool IsOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "_4_Search")
                {
                    IsOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (IsOpen == false)
            {
                _4_Search f4 = new _4_Search();
                f4.MdiParent = this;
                f4.Show();
            }
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool IsOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "_4_Delete")
                {
                    IsOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (IsOpen == false)
            {
                _4_Delete f5 = new _4_Delete();
                f5.MdiParent = this;
                f5.Show();
            }
        }

        private void closeAllOpenFormsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
        }

        private void lOOKUPToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void rEPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool IsOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "_4_REPORT")
                {
                    IsOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (IsOpen == false)
            {
                _4_Report f7 = new _4_Report();
                f7.MdiParent = this;
                f7.Show();
            }
        }
    }
}
