﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KHOA_2
{
    public partial class Bai_them : Form
    {
        public Bai_them()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool IsOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text=="Bai_them1")
                {
                    IsOpen = true;
                    f.Focus();
                    break;
                }
            }
            if(IsOpen== false)
            {
               Bai_them1 f2 = new Bai_them1();
               f2.MdiParent = this;
               f2.Show();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form f3 = new Bai_them3();
            f3.MdiParent = this;
            f3.Show();

        }

        private void closeAllFormsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach(Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();

                }
            }
        }
    }
}
