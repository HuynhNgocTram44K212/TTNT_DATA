﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KHOA_2
{
    public partial class Bai_them1 : Form
    {
        public Bai_them1()
        {
            InitializeComponent();
        }
    }
}
