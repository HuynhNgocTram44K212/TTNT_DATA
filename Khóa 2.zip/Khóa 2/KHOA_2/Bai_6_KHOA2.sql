--1
create Proc PhongBan_SelectAll
AS
Begin
   SELECT * FROM PhongBan
End

-- 2
create Proc PhongBan_Insert(

 @TenPhongBan nvarchar(50)
)
AS
Begin
  INSERT INTO PhongBan(TenPhongBan) VALUES (@TenPhongBan)
End

--3
create Proc PhongBan_Update(
   @TenPhongBan nvarchar(50),
  @ID int
   
)
AS
Begin
UPDATE PhongBan Set TenPhongBan=@TenPhongBan
Where ID = @ID
End

--4
create Proc PhongBan_Delete(

   @ID int
   )
AS
Begin
 DELETE FROM PhongBan 
 WHERE ID = @ID
End
---5
Create Proc NhanVien_SelectID
(
@ID int
)
AS
Begin
 Select * from SinhVien 
 where ID= @ID
End
---6
Create Proc NhanVien_Insret
(
@TenSV nvarchar (50),
@QueQuan nvarchar (50),
@ID int
)
AS
Begin
 INSERT into SinhVien(TenSV,QueQuan,ID) 
 Values (@TenSV, @QueQuan, @ID)
End

---7
Create Proc NhanVien_Update
(
@TenSV nvarchar (50),
@QueQuan nvarchar (50),
@MaSV int
)
AS
Begin
 UPDATE SinhVien Set TenSV= @TenSV, QueQuan=@QueQuan
 Where MaSV= @MaSV
End

---8
Create Proc NhanVien_Delete
(
@MaSV int
)
AS
Begin
 Delete From SinhVien
 Where MaSV= @MaSV
End