﻿namespace BT_Them
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFromOnesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFromMultipleTimesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeAllOpenFormsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(721, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openFromOnesToolStripMenuItem,
            this.openFromMultipleTimesToolStripMenuItem,
            this.closeAllOpenFormsToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(69, 29);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // openFromOnesToolStripMenuItem
            // 
            this.openFromOnesToolStripMenuItem.Name = "openFromOnesToolStripMenuItem";
            this.openFromOnesToolStripMenuItem.Size = new System.Drawing.Size(301, 30);
            this.openFromOnesToolStripMenuItem.Text = "Open from ones";
            this.openFromOnesToolStripMenuItem.Click += new System.EventHandler(this.openFromOnesToolStripMenuItem_Click);
            // 
            // openFromMultipleTimesToolStripMenuItem
            // 
            this.openFromMultipleTimesToolStripMenuItem.Name = "openFromMultipleTimesToolStripMenuItem";
            this.openFromMultipleTimesToolStripMenuItem.Size = new System.Drawing.Size(301, 30);
            this.openFromMultipleTimesToolStripMenuItem.Text = "Open from Multiple times";
            this.openFromMultipleTimesToolStripMenuItem.Click += new System.EventHandler(this.openFromMultipleTimesToolStripMenuItem_Click);
            // 
            // closeAllOpenFormsToolStripMenuItem
            // 
            this.closeAllOpenFormsToolStripMenuItem.Name = "closeAllOpenFormsToolStripMenuItem";
            this.closeAllOpenFormsToolStripMenuItem.Size = new System.Drawing.Size(301, 30);
            this.closeAllOpenFormsToolStripMenuItem.Text = "Close All Open Forms";
            this.closeAllOpenFormsToolStripMenuItem.Click += new System.EventHandler(this.closeAllOpenFormsToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(721, 469);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openFromOnesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openFromMultipleTimesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeAllOpenFormsToolStripMenuItem;
    }
}

