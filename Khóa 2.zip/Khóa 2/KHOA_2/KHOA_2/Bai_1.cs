﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KHOA_2
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=DEMO;Integrated Security=True");

        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
            var cmd = new SqlCommand("PhongBan_SelectAll",conn);
            cmd.CommandType = CommandType.StoredProcedure;
            var dap = new SqlDataAdapter(cmd);
           // var dap = new SqlDataAdapter("SELECT*FROM PhongBan", conn); thay bằng câu lệnh trên
            var table = new DataTable();
            dap.Fill(table);
            cbPhongBan.DisplayMember = "TenPhongBan";
            cbPhongBan.ValueMember = "ID";

            cbPhongBan.DataSource = table;

            txtID.DataBindings.Clear();
            txtID.DataBindings.Add("Text", cbPhongBan.DataSource, "ID");

            txtTenPhongBan.DataBindings.Clear();
            txtTenPhongBan.DataBindings.Add("Text", cbPhongBan.DataSource, "TenPhongBan");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void cbPhongBan_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
            var cmd = new SqlCommand("NhanVien_SelectID", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = Convert.ToInt32(cbPhongBan.SelectedValue);

            //int id = Convert.ToInt32(cbPhongBan.SelectedValue);
            var dap = new SqlDataAdapter(cmd);

            var table = new DataTable();

            dap.Fill(table);
            dgvNhanVien.DataSource = table;

            txtMaNhanVien.DataBindings.Clear();
            txtMaNhanVien.DataBindings.Add("Text", dgvNhanVien.DataSource, "MaSV");

            txtHoTen.DataBindings.Clear();
            txtHoTen.DataBindings.Add("Text", dgvNhanVien.DataSource, "TenSV");

            txtQueQuan.DataBindings.Clear();
            txtQueQuan.DataBindings.Add("Text", dgvNhanVien.DataSource, "QueQuan");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        Boolean addPB = false;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtTenPhongBan.Text = "";
            txtTenPhongBan.Focus();
            addPB = true;


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (addPB == true)
            {
                try
                {
                    conn.Open();
                    var cmd = new SqlCommand("PhongBan_Insert", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@TenPhongBan", SqlDbType.NVarChar).Value = txtTenPhongBan.Text;
                   
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    frmMain_Load(sender, e);
                    MessageBox.Show("Thêm dữ liệu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Thêm dữ liệu thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                addPB = false;
            }
            else
            {
                try
                {
                   
                    conn.Open();
                    var cmd = new SqlCommand("PhongBan_Update", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@TenPhongBan", SqlDbType.NVarChar).Value = txtTenPhongBan.Text;
                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = Convert.ToInt32(cbPhongBan.SelectedValue);
                   // var cmd = new SqlCommand("UPDATE PhongBan SET TenPhongBan = N'"
                   //     + txtTenPhongBan.Text + "'WHERE ID =" + Convert.ToInt32(cbPhongBan.SelectedValue) + "", conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    frmMain_Load(sender, e);
                    cbPhongBan_SelectedIndexChanged(sender, e);
                    MessageBox.Show("Sửa dữ liệu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Sửa dữ liệu thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult lenh = MessageBox.Show("Bạn có chắc chán xóa " + cbPhongBan.Text + " ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (lenh == DialogResult.Yes)
            {
                try
                {
                    conn.Open();
                    var cmd = new SqlCommand("PhongBan_Delete", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = Convert.ToInt32(cbPhongBan.SelectedValue);
                    //var cmd = new SqlCommand("DELETE FROM PhongBan WHERE ID =" + Convert.ToInt32(cbPhongBan.SelectedValue) + "", conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    frmMain_Load(sender, e);
                    cbPhongBan_SelectedIndexChanged(sender, e);
                    MessageBox.Show("Xóa dữ liệu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Xóa dữ liệu thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        Boolean addNV = false;
        private void btnAddNV_Click(object sender, EventArgs e)
        {
            txtMaNhanVien.Text = "";
            txtHoTen.Text = "";
            txtQueQuan.Text = "";
            txtHoTen.Focus();
            addNV = true;

        }

        private void btnUpdateNV_Click(object sender, EventArgs e)
        {
            if (addNV == true)
            {
                try
                {
                    conn.Open();
                    var cmd = new SqlCommand("NhanVien_Insert", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@TenSV", SqlDbType.NVarChar).Value = txtHoTen.Text;
                    cmd.Parameters.Add("@QueQuan", SqlDbType.NVarChar).Value = txtQueQuan.Text;
                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = Convert.ToInt32(cbPhongBan.SelectedValue);
                    //var cmd = new SqlCommand("INSERT INTO SinhVien(TenSV, QueQuan, ID) VALUES(N'"
                     //   + txtHoTen.Text + "',N'" + txtQueQuan.Text + "'," + Convert.ToInt32(cbPhongBan.SelectedValue) + " )", conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    cbPhongBan_SelectedIndexChanged(sender, e);
                    MessageBox.Show("Thêm nhân viên thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                 
                }
                catch
                {
                    MessageBox.Show("Thêm nhân viên thất bại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                addNV = false;

            }
            else
            {
                try
                {
                    conn.Open();
                    var cmd = new SqlCommand("NhanVien_Update", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@TenSV", SqlDbType.NVarChar).Value = txtHoTen.Text;
                    cmd.Parameters.Add("@QueQuan", SqlDbType.NVarChar).Value = txtQueQuan.Text;
                    cmd.Parameters.Add("@MaSV", SqlDbType.Int).Value = Convert.ToInt32(txtMaNhanVien.Text);
                   // var cmd = new SqlCommand("UPDATE SinhVien SET TenSV = N'"
                    //    + txtHoTen.Text + "', QueQuan=N'" + txtQueQuan.Text + "'WHERE MaSV ="
                    //    + Convert.ToInt32(txtMaNhanVien.Text) + "", conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    cbPhongBan_SelectedIndexChanged(sender, e);
                    MessageBox.Show("Thêm nhân viên thành công!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                catch
                {
                    MessageBox.Show("Thêm nhân viên thất bại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
        }

        private void btnDeleteNV_Click(object sender, EventArgs e)
        {
                DialogResult lenh = MessageBox.Show("Bạn có chắc muốn xóa nhân viên " + txtHoTen.Text + " ?", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (lenh == DialogResult.Yes)
                {
                    try
                    {
                        conn.Open();
                        var cmd = new SqlCommand("NhanVien_Delete", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        
                        cmd.Parameters.Add("@MaSV", SqlDbType.Int).Value = Convert.ToInt32(txtMaNhanVien.Text);
                       // var cmd = new SqlCommand("DELETE From SinhVien WHERE MaSV ="
                       //     + Convert.ToInt32(txtMaNhanVien.Text) + "", conn);
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        cbLop_SelectedIndexChanged(sender, e);
                        MessageBox.Show("Xóa nhân viên thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch
                    {
                        MessageBox.Show("Xóa dữ liệu thất bại !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }

            }

        private void cbLop_SelectedIndexChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        

    }
}
