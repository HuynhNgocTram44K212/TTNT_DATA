﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Nhom4_THUCTAP
{
    public partial class _4_Add : Form
    {
        public _4_Add()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");
        private void _4_Add_Load(object sender, EventArgs e)
        {
            
        }
    }
}
