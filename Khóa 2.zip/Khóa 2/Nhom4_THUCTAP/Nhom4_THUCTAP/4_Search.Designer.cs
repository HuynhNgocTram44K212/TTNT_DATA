﻿namespace Nhom4_THUCTAP
{
    partial class _4_Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTIM = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.l = new System.Windows.Forms.Label();
            this.dgvHocVien = new System.Windows.Forms.DataGridView();
            this.cbLop = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.IDHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtIDLop = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocVien)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(282, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(326, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "TÌM THÔNG TIN HỌC VIÊN";
            // 
            // txtTIM
            // 
            this.txtTIM.BackColor = System.Drawing.Color.AntiqueWhite;
            this.txtTIM.Location = new System.Drawing.Point(571, 63);
            this.txtTIM.Name = "txtTIM";
            this.txtTIM.Size = new System.Drawing.Size(127, 26);
            this.txtTIM.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(467, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên học viên";
            // 
            // l
            // 
            this.l.AutoSize = true;
            this.l.Location = new System.Drawing.Point(233, 69);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(67, 20);
            this.l.TabIndex = 3;
            this.l.Text = "Tên Lớp";
            // 
            // dgvHocVien
            // 
            this.dgvHocVien.BackgroundColor = System.Drawing.Color.Gray;
            this.dgvHocVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHocVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDHocVien,
            this.IDLop,
            this.TenHocVien,
            this.HocPhi});
            this.dgvHocVien.Location = new System.Drawing.Point(12, 114);
            this.dgvHocVien.Name = "dgvHocVien";
            this.dgvHocVien.RowTemplate.Height = 28;
            this.dgvHocVien.Size = new System.Drawing.Size(930, 427);
            this.dgvHocVien.TabIndex = 11;
            // 
            // cbLop
            // 
            this.cbLop.BackColor = System.Drawing.Color.AntiqueWhite;
            this.cbLop.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cbLop.FormattingEnabled = true;
            this.cbLop.Location = new System.Drawing.Point(306, 61);
            this.cbLop.Name = "cbLop";
            this.cbLop.Size = new System.Drawing.Size(121, 28);
            this.cbLop.TabIndex = 12;
            this.cbLop.SelectedIndexChanged += new System.EventHandler(this.cbLop_SelectedIndexChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Gainsboro;
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSearch.Location = new System.Drawing.Point(719, 61);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(87, 30);
            this.btnSearch.TabIndex = 13;
            this.btnSearch.Text = "Tìm kiếm";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // IDHocVien
            // 
            this.IDHocVien.DataPropertyName = "IDHocVien";
            this.IDHocVien.HeaderText = "ID Học Viên";
            this.IDHocVien.Name = "IDHocVien";
            // 
            // IDLop
            // 
            this.IDLop.DataPropertyName = "IDLop";
            this.IDLop.HeaderText = "ID Lớp";
            this.IDLop.Name = "IDLop";
            this.IDLop.Visible = false;
            // 
            // TenHocVien
            // 
            this.TenHocVien.DataPropertyName = "TenHocVien";
            this.TenHocVien.HeaderText = "Tên Học Viên";
            this.TenHocVien.Name = "TenHocVien";
            this.TenHocVien.Width = 300;
            // 
            // HocPhi
            // 
            this.HocPhi.DataPropertyName = "HocPhi";
            this.HocPhi.HeaderText = "Học Phí";
            this.HocPhi.Name = "HocPhi";
            this.HocPhi.Width = 200;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(827, 61);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 29);
            this.button1.TabIndex = 14;
            this.button1.Text = "Thoát";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "ID Lớp";
            // 
            // txtIDLop
            // 
            this.txtIDLop.BackColor = System.Drawing.Color.AntiqueWhite;
            this.txtIDLop.Enabled = false;
            this.txtIDLop.Location = new System.Drawing.Point(81, 63);
            this.txtIDLop.Name = "txtIDLop";
            this.txtIDLop.Size = new System.Drawing.Size(127, 26);
            this.txtIDLop.TabIndex = 16;
            // 
            // _4_Search
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(967, 568);
            this.Controls.Add(this.txtIDLop);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.cbLop);
            this.Controls.Add(this.dgvHocVien);
            this.Controls.Add(this.l);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTIM);
            this.Controls.Add(this.label1);
            this.Name = "_4_Search";
            this.Text = "_4_Search";
            this.Load += new System.EventHandler(this._4_Search_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTIM;
        private System.Windows.Forms.Label l;
        private System.Windows.Forms.DataGridView dgvHocVien;
        private System.Windows.Forms.ComboBox cbLop;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDLop;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn HocPhi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtIDLop;
    }
}