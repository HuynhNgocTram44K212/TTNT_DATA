﻿namespace Nhom4_THUCTAP
{
    partial class _4_Delete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.dgvHocVien = new System.Windows.Forms.DataGridView();
            this.IDHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDLop1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHocVien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.txtHocphi = new System.Windows.Forms.TextBox();
            this.txtTenHocVien = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIDHocVien = new System.Windows.Forms.TextBox();
            this.btnXoa = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbLop = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.IDLop = new System.Windows.Forms.Label();
            this.txtIDLop = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocVien)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(564, 495);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 40);
            this.button1.TabIndex = 21;
            this.button1.Text = "Thoát";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // dgvHocVien
            // 
            this.dgvHocVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHocVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDHocVien,
            this.TenLop,
            this.IDLop1,
            this.TenHocVien,
            this.HocPhi});
            this.dgvHocVien.Location = new System.Drawing.Point(108, 103);
            this.dgvHocVien.Name = "dgvHocVien";
            this.dgvHocVien.RowTemplate.Height = 28;
            this.dgvHocVien.Size = new System.Drawing.Size(772, 302);
            this.dgvHocVien.TabIndex = 20;
            // 
            // IDHocVien
            // 
            this.IDHocVien.DataPropertyName = "IDHocVien";
            this.IDHocVien.HeaderText = "ID Học Viên";
            this.IDHocVien.Name = "IDHocVien";
            // 
            // TenLop
            // 
            this.TenLop.DataPropertyName = "TenLop";
            this.TenLop.HeaderText = "Tên Lớp";
            this.TenLop.Name = "TenLop";
            this.TenLop.Visible = false;
            // 
            // IDLop1
            // 
            this.IDLop1.DataPropertyName = "IDLop1";
            this.IDLop1.HeaderText = "ID Lớp";
            this.IDLop1.Name = "IDLop1";
            this.IDLop1.Visible = false;
            // 
            // TenHocVien
            // 
            this.TenHocVien.DataPropertyName = "TenHocVien";
            this.TenHocVien.HeaderText = "Tên Học Viên";
            this.TenHocVien.Name = "TenHocVien";
            this.TenHocVien.Width = 200;
            // 
            // HocPhi
            // 
            this.HocPhi.DataPropertyName = "HocPhi";
            this.HocPhi.HeaderText = "Học Phí";
            this.HocPhi.Name = "HocPhi";
            this.HocPhi.Width = 200;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(186, 537);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "Học phí";
            // 
            // txtHocphi
            // 
            this.txtHocphi.Location = new System.Drawing.Point(318, 537);
            this.txtHocphi.Name = "txtHocphi";
            this.txtHocphi.Size = new System.Drawing.Size(196, 26);
            this.txtHocphi.TabIndex = 18;
            // 
            // txtTenHocVien
            // 
            this.txtTenHocVien.Location = new System.Drawing.Point(318, 493);
            this.txtTenHocVien.Name = "txtTenHocVien";
            this.txtTenHocVien.Size = new System.Drawing.Size(196, 26);
            this.txtTenHocVien.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(186, 493);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Tên học viên";
            // 
            // txtIDHocVien
            // 
            this.txtIDHocVien.Enabled = false;
            this.txtIDHocVien.Location = new System.Drawing.Point(318, 445);
            this.txtIDHocVien.Name = "txtIDHocVien";
            this.txtIDHocVien.Size = new System.Drawing.Size(196, 26);
            this.txtIDHocVien.TabIndex = 15;
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(564, 442);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(175, 40);
            this.btnXoa.TabIndex = 14;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(186, 451);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "ID Học Viên";
            // 
            // cbLop
            // 
            this.cbLop.FormattingEnabled = true;
            this.cbLop.Location = new System.Drawing.Point(190, 60);
            this.cbLop.Name = "cbLop";
            this.cbLop.Size = new System.Drawing.Size(163, 28);
            this.cbLop.TabIndex = 23;
            this.cbLop.SelectedIndexChanged += new System.EventHandler(this.cbLop_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 20);
            this.label3.TabIndex = 22;
            this.label3.Text = "Tên lớp";
            // 
            // IDLop
            // 
            this.IDLop.AutoSize = true;
            this.IDLop.Location = new System.Drawing.Point(580, 62);
            this.IDLop.Name = "IDLop";
            this.IDLop.Size = new System.Drawing.Size(57, 20);
            this.IDLop.TabIndex = 25;
            this.IDLop.Text = "ID Lớp";
            // 
            // txtIDLop
            // 
            this.txtIDLop.Enabled = false;
            this.txtIDLop.Location = new System.Drawing.Point(662, 60);
            this.txtIDLop.Name = "txtIDLop";
            this.txtIDLop.Size = new System.Drawing.Size(100, 26);
            this.txtIDLop.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label5.Location = new System.Drawing.Point(313, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(330, 26);
            this.label5.TabIndex = 27;
            this.label5.Text = "XÓA THÔNG TIN HỌC VIÊN";
            // 
            // _4_Delete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 609);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtIDLop);
            this.Controls.Add(this.IDLop);
            this.Controls.Add(this.cbLop);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvHocVien);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtHocphi);
            this.Controls.Add(this.txtTenHocVien);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtIDHocVien);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.label1);
            this.Name = "_4_Delete";
            this.Text = "_4_Delete";
            this.Load += new System.EventHandler(this._4_Delete_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHocVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgvHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenLop;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDLop1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHocVien;
        private System.Windows.Forms.DataGridViewTextBoxColumn HocPhi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtHocphi;
        private System.Windows.Forms.TextBox txtTenHocVien;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIDHocVien;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbLop;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label IDLop;
        private System.Windows.Forms.TextBox txtIDLop;
        private System.Windows.Forms.Label label5;
    }
}