﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Nhom4_THUCTAP
{
    public partial class _4_Search : Form
    {
        public _4_Search()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");
        private void _4_Search_Load(object sender, EventArgs e)
        {
           
            try
            {
                var cmd = new SqlCommand("DMLOP_SELECTAll", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                var dap = new SqlDataAdapter(cmd);



                var table = new DataTable();
                dap.Fill(table);
                cbLop.DisplayMember = "TenLop";
                cbLop.ValueMember = "IDLop";

                cbLop.DataSource = table;
                txtIDLop.DataBindings.Clear();
                txtIDLop.DataBindings.Add("Text", cbLop.DataSource, "IDLop");

            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void cbLop_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("HOCVIEN_SELECTID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbLop.SelectedValue);

                var dap = new SqlDataAdapter(cmd);

                var table = new DataTable();

                dap.Fill(table);
                dgvHocVien.DataSource = table;

               
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        void timdata()
        {
            try 
            { 
                if (!txtTIM.Text.Equals(""))
                {
                var cmd = new SqlCommand();
                cmd = conn.CreateCommand();
                cmd.CommandText = "Select IDHocVien, TenHocVien, HocPhi from DMLOP inner join HOCVIEN on HOCVIEN.IDLop = DMLOP.IDLop where TenHocVien like N'%" + txtTIM.Text + "%' and TenLop=N'" + cbLop.Text + "'";
                
                var dap = new SqlDataAdapter(cmd);
                var table = new DataTable();
                dap.SelectCommand = cmd;
                table.Clear();
                dap.Fill(table);
                dgvHocVien.DataSource = table;
                  }
            }
           catch
            
            {
                MessageBox.Show("Bạn chưa ghi Tên Học viên!", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       
        private void btnSearch_Click(object sender, EventArgs e)
        { 
            timdata();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
