﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Nhom4_THUCTAP
{
    public partial class _4_Update : Form
    {
        public _4_Update()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");
       

        private void _4_Update_Load(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("DMLOP_SELECTAll", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                var dap = new SqlDataAdapter(cmd);

                
                
                var table = new DataTable();
                dap.Fill(table);
                cbLop.DisplayMember = "TenLop";
                cbLop.ValueMember = "IDLop";
               
                cbLop.DataSource = table;
                txtIDLop.DataBindings.Clear();
                txtIDLop.DataBindings.Add("Text", cbLop.DataSource, "IDLop");
                 
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void cbLop_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("HOCVIEN_SELECTID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbLop.SelectedValue);
             
                var dap = new SqlDataAdapter(cmd);
               
                var table = new DataTable();
                
                dap.Fill(table);
                dgvHocVien.DataSource = table;

                txtIDHocVien.DataBindings.Clear();
                txtIDHocVien.DataBindings.Add("Text", dgvHocVien.DataSource, "IDHocVien");

                txtTenhv.DataBindings.Clear();
                txtTenhv.DataBindings.Add("Text", dgvHocVien.DataSource, "TenHocVien");

                txtHocphi.DataBindings.Clear();
                txtHocphi.DataBindings.Add("Text", dgvHocVien.DataSource, "HocPhi");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                var cmd = new SqlCommand("HOCVIEN_UPDATE", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@TenHocVien", SqlDbType.NVarChar).Value = txtTenhv.Text;
                cmd.Parameters.Add("@HocPhi", SqlDbType.Int).Value =Convert.ToInt32( txtHocphi.Text);
                cmd.Parameters.Add("@IDHocVien", SqlDbType.Int).Value = Convert.ToInt32(txtIDHocVien.Text);
                
                cmd.ExecuteNonQuery();
                conn.Close();
                cbLop_SelectedIndexChanged(sender, e);
                MessageBox.Show("Cập nhật học viên thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch
            {
                MessageBox.Show("Cập nhật học viên thất bại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

       
    }
}
