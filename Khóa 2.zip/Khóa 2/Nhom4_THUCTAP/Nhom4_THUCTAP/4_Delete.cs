﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Nhom4_THUCTAP
{
    public partial class _4_Delete : Form
    {
        public _4_Delete()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=ADMIN\TRAM;Initial Catalog=QuanLyPhongBan;Integrated Security=True");
        private void _4_Delete_Load(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("DMLOP_SELECTAll", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                var dap = new SqlDataAdapter(cmd);



                var table = new DataTable();
                dap.Fill(table);
                cbLop.DisplayMember = "TenLop";
                cbLop.ValueMember = "IDLop";
                cbLop.DataSource = table;
                txtIDLop.DataBindings.Clear();
                txtIDLop.DataBindings.Add("Text", cbLop.DataSource, "IDLop");


                

            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void cbLop_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand("HOCVIEN_SELECTID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDLop", SqlDbType.Int).Value = Convert.ToInt32(cbLop.SelectedValue);

                var dap = new SqlDataAdapter(cmd);

                var table = new DataTable();

                dap.Fill(table);
                dgvHocVien.DataSource = table;

                txtIDHocVien.DataBindings.Clear();
                txtIDHocVien.DataBindings.Add("Text", dgvHocVien.DataSource, "IDHocVien");

                txtTenHocVien.DataBindings.Clear();
                txtTenHocVien.DataBindings.Add("Text", dgvHocVien.DataSource, "TenHocVien");

                txtHocphi.DataBindings.Clear();
                txtHocphi.DataBindings.Add("Text", dgvHocVien.DataSource, "HocPhi");
            }
            catch
            {
                MessageBox.Show("Load dữ liệu thất bại. Kiểm tra lại SQL Server trên máy tính của bạn", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
              DialogResult lenh = MessageBox.Show("Bạn có chắc muốn xóa học viên " + txtTenHocVien.Text + " ?", "Thông báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
              if (lenh == DialogResult.Yes)
              {
                 try
                  {
                      conn.Open();
                      var cmd = new SqlCommand("HOCVIEN_DELETE", conn);
                      cmd.CommandType = CommandType.StoredProcedure;

                      cmd.Parameters.Add("@IDHocVien", SqlDbType.Int).Value = Convert.ToInt32(txtIDHocVien.Text);

                      cmd.ExecuteNonQuery();
                      conn.Close();
                      cbLop_SelectedIndexChanged(sender, e);
                      MessageBox.Show("Xóa học viên hành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                 }
                 catch
                 {
                     MessageBox.Show("Xóa học viên thất bại !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);

                  }
              }
        }
    }
}
