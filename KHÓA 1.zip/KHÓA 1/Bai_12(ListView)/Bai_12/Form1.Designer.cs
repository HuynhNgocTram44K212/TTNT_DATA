﻿namespace Bai_12
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item 1",
            "44k21.2",
            "07944243454"}, 0);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item 2",
            "Đà Nẵng",
            "0823334456"}, 2);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item 3",
            "22"}, 1);
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listView1 = new System.Windows.Forms.ListView();
            this.largeimageML = new System.Windows.Forms.ImageList(this.components);
            this.smallIML = new System.Windows.Forms.ImageList(this.components);
            this.Tên = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Lớp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Tên,
            this.Lớp,
            this.columnHeader1});
            this.listView1.GridLines = true;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3});
            this.listView1.LargeImageList = this.largeimageML;
            this.listView1.Location = new System.Drawing.Point(61, 34);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(505, 393);
            this.listView1.SmallImageList = this.smallIML;
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // largeimageML
            // 
            this.largeimageML.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("largeimageML.ImageStream")));
            this.largeimageML.TransparentColor = System.Drawing.Color.Transparent;
            this.largeimageML.Images.SetKeyName(0, "hinh-nen-cho-laptop-hinh-nen-thiet-ke-dep_111331168.jpg");
            this.largeimageML.Images.SetKeyName(1, "hinh-nen-cho-laptop-nhung-minions-sieu-de-thuong_111333461.jpg");
            this.largeimageML.Images.SetKeyName(2, "hinh-nen-cho-laptop-phong-canh-thien-nhien-dep_111334397.jpg");
            // 
            // smallIML
            // 
            this.smallIML.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("smallIML.ImageStream")));
            this.smallIML.TransparentColor = System.Drawing.Color.Transparent;
            this.smallIML.Images.SetKeyName(0, "hinh-nen-cho-laptop-hinh-nen-thiet-ke-dep_111331168.jpg");
            this.smallIML.Images.SetKeyName(1, "hinh-nen-cho-laptop-nhung-minions-sieu-de-thuong_111333461.jpg");
            this.smallIML.Images.SetKeyName(2, "hinh-nen-cho-laptop-phong-canh-thien-nhien-dep_111334397.jpg");
            // 
            // Tên
            // 
            this.Tên.Width = 135;
            // 
            // Lớp
            // 
            this.Lớp.Width = 119;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 145;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 522);
            this.Controls.Add(this.listView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Tên;
        private System.Windows.Forms.ColumnHeader Lớp;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ImageList largeimageML;
        private System.Windows.Forms.ImageList smallIML;
    }
}

