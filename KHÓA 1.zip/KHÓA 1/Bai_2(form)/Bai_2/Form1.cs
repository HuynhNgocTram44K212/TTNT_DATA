﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_2
{
    public partial class name1 : Form
    {
        public name1()
        {
            InitializeComponent();
        }
        int i = 1;
        private void name1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn đã click lên form " +i +" lần rồi nha :))");
            i++; 
        }
    }
}
