﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
           // MessageBox.Show("Click");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("CheckedChanged");
        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("CheckStateChanged");
        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            string Name = txbName.Text;
            //check thử có phải hay không là kter
            string kter = ckbKter.CheckState == CheckState.Checked ? "là" : ckbKter.CheckState == CheckState.Unchecked ? "không phải là" : "phải và không phải là";
            string showString = string.Format("chào bạn {0}, bạn {1} là Kter", Name, kter);
            MessageBox.Show(showString);
        }
    }
}
