﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Tạo 1 button và khi kick vào sẽ có text trên Panel một vị trí random
            //Button btn = new Button();
            //btn.Text = "HowKteam.com";
            //btn.AutoSize = true;

           //Random rand = new Random();
            //btn.Location = new Point(rand.Next(0, pnlButton.Size.Width), rand.Next(0, pnlButton.Size.Height));

            //pnlButton.Controls.Add(btn);


            // Như trên nhưng là panel được xếp lại thành hàng do FlowLayoutPanel
            Button btn = new Button();
            btn.Text = "Hello!!";
            btn.AutoSize = true;
            fpnlButton.Controls.Add(btn);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // muốn bấm vào được hay không
            fpnlButton.Enabled = !fpnlButton.Enabled;
        }
    }
}
