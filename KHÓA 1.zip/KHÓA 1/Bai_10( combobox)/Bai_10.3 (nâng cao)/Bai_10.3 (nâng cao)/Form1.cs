﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_10._3__nâng_cao_
{
    public partial class Form1 : Form
    {
        public Form1()   // ĐỀ BÀI: Tạo ra 1 danh sách khoa và lớp, khi chọn một khoa sẽ hiển thi các lớp tương ứng trong khoa đó.
        {
            InitializeComponent();
           //b4.2 AddClassBinding();  dùng không được

            List<CBClass> ListClass;     //b3: tạo tên cho danh sách
            ListClass = new List<CBClass>();


            // b3.1: Tạo danh sách từng lớp 

            ListClass.Add(new CBClass()
            {
                ClassName = "44k21.1",
                ListStudent = new List<string>() { "Nguyễn Văn A", "Phạm Thị B", "Trần C" }
            });


            ListClass.Add(new CBClass()
            {
                ClassName = "44k21.2",
                ListStudent = new List<string>() { "Nguyễn Ngọc G", "Đỗ Thị D", "Đặng M" }
            });


            //b3.2: Tạo ra list lớp và hiển thị
            cbBranch.DataSource = ListClass;
            cbBranch.DisplayMember = "ClassName";
        }
        // b4.1: Hiển thị Lớp tương ứng dùng k được
       // void AddClassBinding()
      //  {
            //cbClass.DataBindings.Add("DataSource", cbBranch.SelectedValue, "ListStudent");
       // }



        private void Form1_Load(object sender, EventArgs e)
        {

        }
        // b4.1: Hiển thị Lớp tương ứng
        private void cbBranch_SelectedValueChanged(object sender, EventArgs e)
        {
          ComboBox cb = sender as ComboBox;

            if (cb.SelectedValue != null)
            {
                CBClass cl = cb.SelectedValue as CBClass;
                cbClass.DataSource = cl.ListStudent;
            };
        }



    }
    public class CBClass
    {
        public string ClassName { get; set; }//b1: tạo tên lớp
        public List<string> ListStudent { get; set; }//b2: tạo danh sách học sinh
    }
}
