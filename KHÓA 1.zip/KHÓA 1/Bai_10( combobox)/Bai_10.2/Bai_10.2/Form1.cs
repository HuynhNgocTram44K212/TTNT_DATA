﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_10._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //b3:đổ danh sách food vào combobox 
            listitem = new List<Food>()
            {
                new Food() {Name ="Cá Viên Chiên", Price= 20000},
                new Food() {Name ="Nem Chua Rán", Price= 25000},
                new Food() {Name ="Hồ Lô Nướng", Price= 17000},
                new Food() {Name ="Bánh Tráng Trộn", Price= 22000},
            };

            //b4.1: để biết hiện tên món
            comboBox1.DataSource = listitem;
            comboBox1.DisplayMember = "Name";
            AddBingding();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        List<Food> listitem; //b2: gắn vào list
       
        private void button1_Click_1(object sender, EventArgs e)
        {
           
        }

         // b4.2: cách 2: hiển thị giá
        void AddBingding()
        {
            textBox1.DataBindings.Add(new Binding("Text", comboBox1.DataBindings,"Price"));

        }
        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            // b4.2: cách 1: hiển thị giá
         // ComboBox cb = sender as ComboBox;
         // if (cb.SelectedValue != null)
         // {
         //     Food food = cb.SelectedValue as Food;
         //     textBox1.Text = food.Price.ToString();
         // }

        }
}
        public class Food
        {
            //b1: tạo 1 list có tên là food
            public string Name { get; set; }
            public float Price { get; set; }
        }
    }

