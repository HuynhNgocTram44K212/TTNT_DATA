﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // đưa ra phần tử thứ mấy sau
            ComboBox cb = sender as ComboBox;
            MessageBox.Show(cb.SelectedIndex.ToString());

        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            //đưa ra số mình chọn trước
            ComboBox cb = sender as ComboBox;
            MessageBox.Show(cb.SelectedItem.ToString());
        }
        //tạo ra 1 list item để chuẩn bị cho b2
        //List<string> listitem; tạo 1 list có tên là string

        List<Food> listitem; //b2: gắn vào list
        private void button1_Click(object sender, EventArgs e)
        {
            //b3:đổ danh sách food vào combobox và bỏ 2 cái selected ở trên đi
            listitem = new List<Food>()
            {
                new Food() {Name ="Cá Viên Chiên", Price= 20000},
                new Food() {Name ="Nem Chua Rán", Price= 25000},
                new Food() {Name ="Hồ Lô Nướng", Price= 17000},
                new Food() {Name ="Bánh Tráng Trộn", Price= 22000},
            };
            
            // để biết hiện tên món
             comboBox1.DataSource = listitem;
             comboBox1.DisplayMember = "Name"; 
        
                // hiển thị giá
            comboBox2.DataSource = listitem;
            comboBox2.DisplayMember = "Price";
    }

       
}
        public class Food
        {
            //b1: tạo 1 list có tên là food
            public string Name { get; set; }
            public float Price { get; set; }
        }

    }

