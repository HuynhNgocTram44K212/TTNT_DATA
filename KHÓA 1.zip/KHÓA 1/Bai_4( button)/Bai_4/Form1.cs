﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int i = 0;
        void AddButon()
        {
            Random rand = new Random();// tọa độ bất kì khi xuất hiện
            Button btn = new Button() 
            { Text = i.ToString(), Location = new Point(rand.Next(0, this.Size.Width), rand.Next(0, this.Size.Height)) };
           // btn.Text = i.ToString(); tương tự như trên nhưng cũ hơn
            btn.Click += btn_Click; // tạo khi click vào cái được tạo ra

            this.Controls.Add(btn);
            i++;
        }

        void btn_Click(object sender, EventArgs e)
        {
        
            Button btn = sender as Button;//ép kiểu

            MessageBox.Show(btn.Text); //tạo text khi kick vào cái đc tạo ra
        }
        private void button1_Click(object sender, EventArgs e)
        {
            AddButon();

        }
    }
}
