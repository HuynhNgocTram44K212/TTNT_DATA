﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Tạo 2 thông báo không cùng lúc
           // MessageBox.Show("Thông báo nè!!");
           //MessageBox.Show("cái này là messageBox");


            //tạo thông báo và caption
            //MessageBox.Show("Thông báo nè","caption");

            //tạo                     nội dung,        đầu đề, 3 nút yes no cancel,          icon và tiếng       về cấu hình
         // MessageBox.Show("bạn chắc chắn muốn lưu?", "Lưu", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Hand,MessageBoxDefaultButton.Button2, MessageBoxOptions.ServiceNotification);
            

            //muốn yes thì làm gì, no làm gì...
          //DialogResult result = MessageBox.Show("bạn chắc chắn muốn lưu?", "Lưu", MessageBoxButtons.YesNoCancel,
         //     MessageBoxIcon.Hand, MessageBoxDefaultButton.Button2, MessageBoxOptions.ServiceNotification);
         // if (result == System.Windows.Forms.DialogResult.Yes) xong thì làm đk
            

            //tạo như trên nhưng cách khác
            DialogResult result = MessageBox.Show("bạn chắc chắn muốn lưu?", "Lưu", MessageBoxButtons.YesNoCancel,
              MessageBoxIcon.Hand, MessageBoxDefaultButton.Button2, MessageBoxOptions.ServiceNotification);
            switch(result)

            {
                case DialogResult.Abort:
                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Đóng messagebox");
                    break;
                case DialogResult.Ignore:
                    break;
                case DialogResult.No:
                    MessageBox.Show("Bạn không lưu");
                    break;
                case DialogResult.None:
                    break;
                case DialogResult.OK:
                    break;
                case DialogResult.Retry:
                    break;
                case DialogResult.Yes:
                    MessageBox.Show("Bạn đã lưu");
                    break;
                default:
                    break;
            }
        }
    }
}
