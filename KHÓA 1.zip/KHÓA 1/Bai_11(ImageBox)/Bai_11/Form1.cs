﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_11
{
    public partial class Form1 : Form
    {
        public Form1()
        { 
            InitializeComponent();
            LoadImageName();


        }

        // nhấn vào button là ra hình ảnh
      //private void button1_Click(object sender, EventArgs e)
      //{
        //  pictureBox1.Image = new Bitmap(Application.StartupPath + "\\Resources\\1.jpg");
      //}
        string Extention = ".pnj";
        void LoadImageName()
        {
            List<string> ListImage = new List<string>() {"1","2","3"};
            cbImage.DataSource = ListImage;
        }

        private void cbImage_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            if (cb.SelectedValue != null)
            {
                Bitmap bm = new Bitmap(Application.StartupPath + "\\Resources\\" + cb.SelectedValue.ToString() + Extention);
                pcbImage.Image = bm;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
