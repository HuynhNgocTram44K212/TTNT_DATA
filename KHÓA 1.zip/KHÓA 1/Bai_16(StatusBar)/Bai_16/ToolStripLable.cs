﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bai_16
{
    class ToolStripLable
    {
        public string Name { get; set; }
    }
}
