﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // lấy dữ liệu từ combo box hiện lên lable qua nhấn nút button
            string str = mntsCombo.SelectedItem.ToString();
            label1.Text = str;
        }

        private void k121ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chào mừng bạn đến với lớp 44k21.1");
        }
    }
}
