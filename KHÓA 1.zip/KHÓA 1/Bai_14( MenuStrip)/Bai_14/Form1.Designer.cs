﻿namespace Bai_14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lớpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trườngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nơiỞToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.k121ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.k212ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.k14ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sưPhạmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kinhTếToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báchKhoaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đàNẵngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.huếToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quãngNamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.mntsCombo = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lớpToolStripMenuItem,
            this.trườngToolStripMenuItem,
            this.nơiỞToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(602, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lớpToolStripMenuItem
            // 
            this.lớpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.k121ToolStripMenuItem,
            this.k212ToolStripMenuItem,
            this.k14ToolStripMenuItem,
            this.toolStripTextBox1,
            this.mntsCombo});
            this.lớpToolStripMenuItem.Name = "lớpToolStripMenuItem";
            this.lớpToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.lớpToolStripMenuItem.Text = "Lớp";
            // 
            // trườngToolStripMenuItem
            // 
            this.trườngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sưPhạmToolStripMenuItem,
            this.kinhTếToolStripMenuItem,
            this.báchKhoaToolStripMenuItem});
            this.trườngToolStripMenuItem.Name = "trườngToolStripMenuItem";
            this.trườngToolStripMenuItem.Size = new System.Drawing.Size(80, 29);
            this.trườngToolStripMenuItem.Text = "Trường";
            // 
            // nơiỞToolStripMenuItem
            // 
            this.nơiỞToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đàNẵngToolStripMenuItem,
            this.huếToolStripMenuItem,
            this.quãngNamToolStripMenuItem});
            this.nơiỞToolStripMenuItem.Name = "nơiỞToolStripMenuItem";
            this.nơiỞToolStripMenuItem.Size = new System.Drawing.Size(68, 29);
            this.nơiỞToolStripMenuItem.Text = "Nơi ở";
            // 
            // k121ToolStripMenuItem
            // 
            this.k121ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5});
            this.k121ToolStripMenuItem.Name = "k121ToolStripMenuItem";
            this.k121ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.k121ToolStripMenuItem.Size = new System.Drawing.Size(220, 30);
            this.k121ToolStripMenuItem.Text = "44k12.1";
            this.k121ToolStripMenuItem.Click += new System.EventHandler(this.k121ToolStripMenuItem_Click);
            // 
            // k212ToolStripMenuItem
            // 
            this.k212ToolStripMenuItem.Image = global::Bai_14.Properties.Resources._1;
            this.k212ToolStripMenuItem.Name = "k212ToolStripMenuItem";
            this.k212ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D2)));
            this.k212ToolStripMenuItem.Size = new System.Drawing.Size(220, 30);
            this.k212ToolStripMenuItem.Text = "44k21.2";
            // 
            // k14ToolStripMenuItem
            // 
            this.k14ToolStripMenuItem.Name = "k14ToolStripMenuItem";
            this.k14ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D3)));
            this.k14ToolStripMenuItem.Size = new System.Drawing.Size(220, 30);
            this.k14ToolStripMenuItem.Text = "44k14";
            // 
            // sưPhạmToolStripMenuItem
            // 
            this.sưPhạmToolStripMenuItem.Name = "sưPhạmToolStripMenuItem";
            this.sưPhạmToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.sưPhạmToolStripMenuItem.Text = "Sư Phạm";
            // 
            // kinhTếToolStripMenuItem
            // 
            this.kinhTếToolStripMenuItem.Name = "kinhTếToolStripMenuItem";
            this.kinhTếToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.kinhTếToolStripMenuItem.Text = "Kinh Tế";
            // 
            // báchKhoaToolStripMenuItem
            // 
            this.báchKhoaToolStripMenuItem.Name = "báchKhoaToolStripMenuItem";
            this.báchKhoaToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.báchKhoaToolStripMenuItem.Text = "Bách Khoa";
            // 
            // đàNẵngToolStripMenuItem
            // 
            this.đàNẵngToolStripMenuItem.Name = "đàNẵngToolStripMenuItem";
            this.đàNẵngToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.đàNẵngToolStripMenuItem.Text = "Đà Nẵng";
            // 
            // huếToolStripMenuItem
            // 
            this.huếToolStripMenuItem.Name = "huếToolStripMenuItem";
            this.huếToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.huếToolStripMenuItem.Text = "Huế";
            // 
            // quãngNamToolStripMenuItem
            // 
            this.quãngNamToolStripMenuItem.Name = "quãngNamToolStripMenuItem";
            this.quãngNamToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.quãngNamToolStripMenuItem.Text = "Quãng Nam";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 31);
            // 
            // mntsCombo
            // 
            this.mntsCombo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.mntsCombo.Name = "mntsCombo";
            this.mntsCombo.Size = new System.Drawing.Size(121, 33);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(210, 30);
            this.toolStripMenuItem2.Text = "1";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(210, 30);
            this.toolStripMenuItem3.Text = "2";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(210, 30);
            this.toolStripMenuItem4.Text = "3";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(210, 30);
            this.toolStripMenuItem5.Text = "4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(115, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(251, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 53);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 437);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem lớpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem k121ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem k212ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem k14ToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripComboBox mntsCombo;
        private System.Windows.Forms.ToolStripMenuItem trườngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sưPhạmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kinhTếToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báchKhoaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nơiỞToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đàNẵngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem huếToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quãngNamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}

