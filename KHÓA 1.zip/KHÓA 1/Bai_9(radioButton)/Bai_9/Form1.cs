﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        void ShowResult(Label lb, Panel pnl)
        {
            RadioButton ckb = null;

            foreach (RadioButton item in pnl.Controls)
            {
                if (item != null)
                    if (item.Checked)
                    {
                        ckb = item;
                        break;
                    }
            }

            if (ckb != null)
                lb.Text = ckb.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            ShowResult(label1, pnl1);
            ShowResult(label2, pnl2);
            ShowResult(label3, pnl3);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radio = sender as RadioButton;

            if (radio.Checked)
                label1.Text = radio.Text;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radio = sender as RadioButton;

            if (radio.Checked)
                label2.Text = radio.Text;
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radio = sender as RadioButton;

            if (radio.Checked)
                label3.Text = radio.Text;
        }
    }
}
